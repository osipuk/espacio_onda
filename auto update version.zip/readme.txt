reference link: 
https://medium.com/@johndyer24/creating-and-deploying-an-auto-updating-electron-app-for-mac-and-windows-using-electron-builder-6a3982c0cee6


npm init
npm install -g electron-prebuilt

electron ./main.js

npm i --save-dev electron

npm install --save-dev electron electron-builder
npm install --save electron-updater

"start": "electron ." in package.json

npm start

git init
git remote add origin https://github.com/[YOUR USERNAME]/[YOUR REPO NAME].git
git add .
git commit -m "Create auto-updating app"
git push -u origin master

npm run deploy