const electron = require('electron');
const {app, BrowserWindow, Menu, dialog  } = require('electron');
const path = require('path');
const { autoUpdater } = require('electron-updater');
const { info } = require('console');

let pluginName;
switch (process.platform) {
	case 'win32':
		pluginName = 'flash/pepflashplayer64_32_0_0_293.dll'
		break;
	case 'darwin':
		pluginName = 'flash/PepperFlashPlayer.plugin';
		break;
	case 'linux':
		pluginName = 'flash/libpepflashplayer.so';
		break;
}
app.commandLine.appendSwitch('ppapi-flash-path', path.join(__dirname, '/../', pluginName));
app.commandLine.appendSwitch('ppapi-flash-version', '32.0.0.445')

let win;
const menuTemplate = [
	{
	   label: 'Inicio',
	   submenu: [
		  {
			label: "Salir",
			 role: 'quit'
		  },       
		  {
			 type: 'separator'
		  },
		  {
			 label: 'Versión '+app.getVersion()+''
		  }
	   ]
	},  
	{
	   label: 'Vista',
	   submenu: [
		  {
			label: "Recarga",
			 role: 'reload'
		  },
		//   {  label: "dev",role: 'toggledevtools' },
		  { type: 'separator' },
		  {
			label: "Tamaño original",
			 role: 'resetzoom'
		  },
		  {
			label: "Aumentar",
			 role: 'zoomin'
		  },
		  {
			label: "Reducir",
			 role: 'zoomout'
		  }
	   ]
	},	 
	{
	  label : "Ventana",
	  submenu: [
		 {
		   label : "Pantalla completa",
		   role: 'togglefullscreen'
		 },
		 {
		   label : "Minimizar",
		   role: 'minimize'
		 },
		 {
		   label : "Restaurar",
		   role: 'zoom'
		 },
		 {
		   label : "Cerrar",
		   role: 'close'
		 }
	  ]
    },
	{
	   label : "Ayuda",     
	   submenu: [
		{
		  label: 'Ayuda de Espacio Onda',
		  click: async () => {
			const { shell } = require('electron')
			await shell.openExternal('https://editorial.ondaeduca.com/page/soporte')
		  }
		},
		{
		  label: 'Soporte técnico',
		  click: async () => {
			const { shell } = require('electron')
			await shell.openExternal('https://editorial.ondaeduca.com/page/contactus')
		  }
		},{
		  label: 'Info Licencia',
		  click :   () => {
			showInfoLicencia();
		   
		  }      
		}
	   ]
	}
  ]

  function showInfoLicencia() {
	dialog.showMessageBox({
	type:'info',
	height: '300px',
	 title: `Info Licencia`,
	 message: `CONTRATO DE LICENCIA DE USUARIO FINAL

	 Aviso Legal
	 
	 TITULARIDAD
	 
	 Conforme al Art. 10 de la Ley 34/2002 de 11 de Julio, de servicios de la sociedad de la información y comercio electrónico (en adelante, LSSI), le informamos que la presente página web pertenece a:
	 
	 ONDA EDUCA S.L.U. , con CIF: B99215220 y domicilio social en calle Ramiro I de Aragón nº 24-local, Zaragoza, CP-50017, España e inscrita en el Registro Mercantil de Zaragoza: Tomo 3650, Libro 0, Folio 151, Sec. 8, Hoja Z-47134
	 
	 Con los siguientes datos de contacto:
	 
	 E-mail info@ondaeduca.com ; Teléfono: +34 976 489706
	 
	 Los siguientes términos y condiciones rigen el uso de los productos contenidos en la plataforma digital ESPACIO ONDA, cuyo dominio es www.espacioonda.ondaeduca.com dirigida a usuarios particulares o profesionales (centros educativos, asociaciones, gabinetes, institutos, universidades, hospitales, ...), que para Onda Educa conforman sus clientes (El Cliente), y que éstos contratan y compran a través del sitio web de Onda Educa cuyo dominio es: www.ondaeduca.com y cuyas condiciones legales, uso de cookies y privacidad (ver condiciones legales), conforman, junto con el producto y modalidad elegida durante el proceso de compra, el contrato entre Onda Educa y el Cliente.
	 
	 El PRODUCTO: CONTRATACIÓN, LICENCIA Y USO.
	 
		 La contratación y compra de los productos contenidos en ESPACIO ONDA se realizará exclusivamente a través del sitio web de Onda Educa www.ondaeduca.com y www.espacioonda.ondaeduca.com.
	 
		 Para poder realizar la contratación y compra deberá registrarse en la web y facilitar los datos de carácter personal necesarios para la tramitación, activación, facturación y procesamiento de su pedido. El uso y tratamiento de dichos datos personales se encuentra declarado en nuestra política de privacidad accesible en el sitio web (ver condiciones generales).
	 
		 El producto contenido en Espacio Onda no dispone de un soporte físico y no se envía ningún material físico. La compra del mismo supone el acceso mediante nombre de usuario y contraseña a la plataforma online. Opcionalmente se facilita la descarga de un programa, el navegador ESPACIO ONDA, que permite la instalación de los programas en su equipo, y que facilita un acceso más rápido y cómodo a los archivos de ejecución que conforman cada programa, siendo necesario igualmente número de serie y contraseña, para la identificación del usuario. Opcionalmente y sin ningún compromiso de disponibilidad, algunos programas pueden complementarse con el pedido y posterior envío de guías didácticas, cuadernos y materiales manipulativos impresos. Estos contenidos están igualmente disponibles en versión imprimible desde la plataforma.
	 
		 El navegador Espacio Onda está disponible actualmente pare el Sistema Operativo Windows y garantiza la compatibilidad íntegra de todas las características contenidas en Espacio Onda. Se pueden utilizar otros navegadores que cumplan con los estándares web HTML5, como Chrome, Firefox, Explorer, Edge, Safari, Opera, pero no se garantiza el cien por cien de la compatibilidad de todas las características, ya que depende de las actualizaciones y determinaciones en la política de software de cada desarrollador, quiera aplicar a lo largo del tiempo. Nuestros programas utilizan tecnología Flash de Adobe, lo cual requiere la habilitación de los permisos de ejecución de programas que utilizan flash, en algunos navegadores. Es responsabilidad suya el activar esta característica para poder utilizar nuestros programas. Todos nuestros programas son seguros y están libres de virus y códigos maliciosos. Si no desea activar estos permisos puede hacer uso de nuestro navegador Espacio Onda, no requiere permisos de ejecución de archivos Flash, y sólo permite el acceso a nuestra plataforma, no pudiéndose navegar a ninguna otra dirección de internet.
	 
		  El Navegador Onda Educa ha sido compilado empleando el Chromium Embedded Framework (CEF). CEF es un proyecto open source basado en licencia BSD fundado por Marshall Greenblatt en 2008 sobre la base del proyecto Google Chromium (fork open source del navegador Google Chrome). Bajo los términos y condiciones de la licencia BSD el Navegador Onda Educa hereda la licencia BSD caso de ser distribuido como código fuente.
	 
		 Adobe Flash es propiedad de Adobe. El plug in Adobe Flash se distribuye conjuntamente y de forma indisoluble con el Navegado Onda Educa y solo con el fin de hacer funcional el software contenido en Espacio Onda desarrollado bajo el entorno de programación Flash.
	 
		 La compra o renovación de una licencia incluye el mantenimiento y soporte técnico del software durante un año natural o tres en caso de licencia PLUS, desde la adquisición del producto únicamente para los casos en los que el Cliente adquiera una versión de pago, excluyendo los usuarios que disfruten de un acceso Demo. Dicho soporte técnico se realizará por medio de teléfono y/o correo electrónico, no siendo en ningún caso presencial.
	 
		 Horario:
		 Lunes a viernes de 8.00 a 15.00 (GMT +01/Madrid)
	 
		 Estos horarios podrán ser susceptibles de cambios de cara a adaptarse lo máximo posible a las necesidades de los clientes y siendo publicado en un lugar visible de la web www.ondaeduca.com
	 
		 Ni el soporte técnico ni el mantenimiento incluyen derecho a clases, jornadas u horas de formación. Onda Educa se reserva el derecho a transferir el servicio de soporte técnico y mantenimiento a sus distribuidores, en cuyo caso se lo notificará al Cliente por correo electrónico facilitándole los datos de contacto del distribuidor.
	 
		 En el caso de que, por causas no imputables a Onda Educa, el Cliente no figure como cliente en la base de datos de aquella, éste no tendrá derecho a recibir mantenimiento ni soporte técnico.
	 
		 Se encuentran incluidas las actualizaciones que, dentro del año de duración de este servicio, o de tres en el caso de licencias PLUS, lleve a cabo Onda Educa con la finalidad de subsanar acciones o elementos que no estuvieran funcionando correctamente.
	 
		 El software licenciado, estará limitado al número de usuarios contratados. El uso de un usuario es individual y no se podrá tener acceso simultáneo de más de una persona a la plataforma con un mismo número de serie. Será necesario en todo momento, tanto en accesos online como en acceso mediante navegador Espacio Onda, disponer de conexión a internet, para verificar la identidad del usuario y su autenticación. No es posible su funcionamiento mediante conexión en red. Los usuarios que hayan disfrutado del periodo Demo en su totalidad no podrán volver a tener acceso a la plataforma, salvo autorización expresa a Onda Educa de un periodo de prórroga del mismo.
	 
		 PRECIO
	 
		 Importe, devengo e impuestos
	 
		 El importe del precio (impuestos aplicables no incluidos) y su devengo se determinarán conforme a las modalidades disponibles en cada momento y seleccionadas por el Cliente durante el proceso de compra.
	 
		 Cada parte será responsable del pago de los impuestos que le corresponda satisfacer de conformidad con la ley aplicable.
	 
		 Actualización
	 
		 Onda Educa actualizará sus precios anualmente y serán aplicados en el proceso de compra dentro del cálculo de la oferta para las necesidades seleccionadas por el cliente.
	 
		 Facturas
	 
		 El Cliente autoriza a Onda Educa expresamente a que la facturación del producto se realice por medios electrónicos. Las factura correspondiente a cada compra de producto quedará almacenada en el Área Privada (en formato PDF) propia del cliente dentro de la web www.ondaeduca.com, accesible por las credenciales exclusivas del cliente (usuario / contraseña). Se enviará paralelamente por email o por el canal determinado por el cliente si así se acuerda.
	 
		 No se emitirán facturas de renovación automáticas, sin consentimiento o petición del cliente. Aunque sí queda autorizada el envío de presupuestos de renovación, hasta dos meses antes de la fecha de caducidad de los servicios licenciados.
	 
		 Divisa
	 
		 Los precios del producto se indican exclusivamente en Euros (€) y todos los pagos que hayan de realizarse en la misma divisa.
	 
		 Pagos
	 
		 El pago del precio del Servicio que aparecerá en pantalla durante el proceso de compra, se podrá realizar por distintos medios (tarjeta de crédito, domiciliación bancaria, transferencia bancaria, o cualquier otro medio de pago que en cada momento se señale en pantalla. Para proceder al pago, el Cliente deberá proporcionar y seguir todas y cada una de las instrucciones que aparecen en pantalla. Como sistema de pago electrónico, Onda Educa ofrece una pasarela de pago (TPV virtual) de comercio electrónico. Todos los datos proporcionados a estos efectos son cifrados en su tránsito y son procesados directamente por la entidad bancaria. El cliente asume el compromiso de pago sobre el producto adquirido en el proceso de compra.
	 
		 Nuevas versiones de software
	 
		 Anualmente Onda Educa lanza nuevas versiones y actualizaciones del software que conllevan mejoras e incorporan nuevas funcionalidades al mismo. Estas actualizaciones se encuentran incluidas en el soporte técnico o mantenimiento al que durante un año, o de tres en caso de licencias PLUS, tiene derecho el Cliente.
	 
		 El uso de licencias y compra de programas es aplicable a los programas adquiridos y en ningún caso es obligatoriedad de Onda Educa, ofrecer acceso o soporte de nuevos programas que en el futuro realice Onda Educa sobre la misma plataforma.
	 
		 Licenciamiento y condiciones de uso
	 
		 El producto se rige y debe usarse bajo los términos y condiciones del Contrato de Licencia de Usuario Final (CLUF). Estos términos deben aceptarse por el Cliente antes de proceder a instalar el producto. Sin aceptar estos términos no será posible la instalación del programa.
	 
		 Responsabilidad del Cliente
	 
		 El Cliente reconoce y acepta, voluntaria y expresamente que el uso del producto que realice es bajo su única y exclusiva responsabilidad en todo momento.
	 
		 Consentimiento para la utilización de información
	 
		 EL Cliente acepta y consiente que Onda Educa recopile y utilice información técnica y otro tipo de información relacionada con el uso del software desde el equipo en el que ha sido instalado, entre la que se incluye, la identificación y características técnicas del equipo físico en el que se encuentra instalado el software y sistema operativo. Dicha información será recogida para:
			 Prestar un correcto servicio de actualización.
			 Proporcionar el soporte técnico y mantenimiento adecuados.
			 Evitar posibles fraudes en la instalación del software o uso malintencionado del mismo.
	 
	 PROPIEDAD INTELECTUAL E INDUSTRIAL
	 
	 La web de Onda Educa www.ondaeduca.com y www.espacioonda.ondaeduca.com, así como su software, sus componentes y resto de elementos (incluidas imágenes, audios, vídeos, textos y otros elementos que forman parte del SOFTWARE), documentación adjunta al mismo y cualquier signo distintivo tanto de la empresa como del propio software, son propiedad de Onda Educa. Los respectivos derechos propiedad intelectual e industrial, mientras no se hayan concedido por la presente licencia al Cliente, incluyendo expresamente los derechos de reproducción, transformación, comunicación pública y distribución en todas las formas posibles de explotación que se conocen en la actualidad o que puedan desarrollarse en un futuro.
	 
	 GARANTÍAS Y RÉGIMEN DE RESPONSABILIDADES
	 
	 Exceptuando las garantías establecidas por la legislación española aplicable, Onda Educa no otorga ninguna otra garantía adicional.
	 
	 EL Cliente asume toda la responsabilidad derivada del mal uso o uso incorrecto de la web www.ondaeduca.com y www.espacioonda.ondaeduca.com y su software, exonerando expresamente a Onda Educa de cualquier responsabilidad al respecto. Sin perjuicio de la garantía legal, el software se suministra “tal como es”, sin otra garantía, explícita o implícita. La elección del software adecuado para los resultados deseados por el Cliente, así como su instalación y utilización fuera de las instrucciones dadas por Onda Educa son de responsabilidad exclusiva del Cliente.
	 
	 Sin perjuicio del régimen de responsabilidades establecidos por la legislación española, Onda Educa no será responsable en ningún caso de los daños personales, lucro cesante o daño emergente, ni de cualquier otro tipo de daño que se produzca como consecuencia de accidente, un uso del software o de la web www.ondaeduca.com y www.espacioonda.ondaeduca.com o cualquiera de sus actualizaciones, incorrecto o distinto al permitido bajo la presente licencia, mal uso o abuso por parte del Cliente, y con independencia de que se hubiera informado a Onda Educa de la posibilidad de tales daños.
	 
	 Onda Educa no se hace responsable de las posibles alteraciones o pérdidas de datos que se produjesen en el equipo del Cliente, siendo éste el único responsable de las correspondientes copias de seguridad. Onda Educa aconseja al Cliente realizar una copia de seguridad del ejecutable del software, así como una copia de seguridad diaria de todos los datos introducidos en el software y alojarla en un soporte externo a la unidad donde se haya instalado el software.
	 
	 VIGENCIA Y RESOLUCIÓN
	 
	 Vigencia
	 
	 La relación contractual entre Onda Educa y el Cliente se entenderá celebrada y entrará en vigor el día en el que el Cliente haya aceptado estas Condiciones Generales y completado satisfactoriamente el proceso de compra.
	 
	 La relación contractual tendrá una duración inicial de un año, o de tres en el caso de licencias PLUS, desde su entrada en vigor.
	 
	 Esta duración inicial será prorrogada por otro año, o de tres en el caso de licencias plus, con una nueva compra o una renovación / actualización del producto por parte del cliente salvo que:
	 
		 El Cliente no abone el precio correspondiente a la adquisición/ renovación adquirida.
		 Proceda otra causa de terminación prevista en estas Condiciones Generales.
	 
	 Resolución
	 
	 La relación contractual quedará resuelta por las siguientes causas:
	 
		 Finalización del período por el que se contrata la licencia.
		 Incumplimiento por parte del Cliente de cualquiera de los pactos y obligaciones recogidas en las presentes condiciones generales o el contrato de licencia de usuario.
		 Impago del precio del servicio de software, según la tarifa y producto elegido por el Cliente o, en su caso, de cualquiera de sus cuotas, lo que supondrá el desistimiento unilateral por parte del Cliente y en tal caso, el software dejará de funcionar sin necesidad de aviso alguno por parte de Onda Educa, que no estará obligada a la prestación de cualquiera de los servicios a que se hubiera comprometido en virtud de la presente licencia o cualquier otro compromiso adicional.
	 
	 NOTIFICACIONES
	 
	 Toda comunicación por parte del Cliente hacia Onda Educa deberá hacerse por escrito, bien por correo postal o electrónico a los siguientes domicilios:
	 
	 Onda Educa S.L.U.
	 Calle Ramiro I de Aragón nº 24-local, Zaragoza CP-50017, España
	 info@ondaeduca.com
	 Tel: +34 976489706
	 
	 El Cliente: la dirección postal y electrónica facilitadas a Onda Educa durante el procedimiento de registro y/o compra en la web de Onda Educa. Cualquier cambio de domicilio a efectos de notificaciones deberá ser comunicado por escrito con una antelación mínima de cinco (5) días hábiles.
	 
	 LEGISLACIÓN APLICABLE Y JURISDICCIÓN
	 
	 Para la solución de las controversias que pudiesen surgir por este proceso de compra, adquisición, documento o el uso del software el Cliente acepta expresamente que las mismas se someten a la jurisdicción de los Juzgados y Tribunales de Zaragoza, en España, con renuncia expresa a otra que pudiera corresponderle legalmente.
	 
	 Así mismo el Cliente acepta que el presente contrato queda gobernado por la legislación española y conforme a la misma deberá ser interpretado, siendo la española la ley aplicable a cualquier cuestión que pueda surgir en cuanto a las presentes condiciones y al uso del software.
	 `,
	 buttons: []
	});
   }
  
function createWindow() {	
	const {width, height} = electron.screen.getPrimaryDisplay().workAreaSize;	
	win = new BrowserWindow({
			title: 'Navegador Espacio Onda',
			width: width, height: height,
			icon: __dirname + '/Material Icons_e2bd_256.png',			
			webPreferences: {
				nodeIntegration: true,
				webSecurity: false,
				allowDisplayingInsecureContent: true,
				allowRunningInsecureContent: true,
				plugins: true
		}
  	});
  
  	win.loadURL('https://espacioonda.ondaeduca.com');	
	
	const menu = Menu.buildFromTemplate(menuTemplate);
  	Menu.setApplicationMenu(menu);
  	//win.webContents.openDevTools();

	const ses = win.webContents.session
	ses.clearCache(function() {});

	win.maximize();

	// Emitted when the window is closed.
	win.on('closed', () => {		
		win = null;
  	});
  
	win.once('ready-to-show', () => {
		autoUpdater.checkForUpdatesAndNotify();
	});


	win.webContents.on('new-window', (event, url) => {
		console.log("thanks")
		// event.preventDefault()
		// const win = new BrowserWindow({show: false})
		// win.once('ready-to-show', () => win.show())
		// win.loadURL(url)
		// event.newGuest = win
	  })

};

autoUpdater.on('update-available', (e) => {
  console.error("update-available.."+e)
  dialog.showMessageBox(win, {
	type: 'info',
    buttons: ["Cerrar"],
    message: "Hay una nueva actualización disponible. Descargando ahora ..."
  })
});

autoUpdater.on('update-downloaded', () => {
  let response = dialog.showMessageBox(win, {
    buttons: ["Reiniciar","Cerrar"],
    message: "Actualización descargada. Se instalará al reiniciar. ¿Reiniciar ahora?"
  },(res, checked) => {
    if (res === 0){
      autoUpdater.quitAndInstall();      
    }else if (res === 1) {
     //No button pressed
    }else if (res === 2){
      console.log("restart cancelled!")
    }
   })
  
});

autoUpdater.on('update-downloaded', (event, releaseNotes, releaseName) => {
	const dialogOpts = {
	  type: 'info',
	  buttons: ['Restart', 'Later'],
	  title: 'Application Update',
	  message: process.platform === 'win32' ? releaseNotes : releaseName,
	  detail: 'A new version has been downloaded. Restart the application to apply the updates.'
	}
  
	dialog.showMessageBox(dialogOpts).then((returnValue) => {
	  if (returnValue.response === 0) autoUpdater.quitAndInstall()
	})
  })

autoUpdater.on('error', message => {
	console.error('There was a problem updating the application')
	console.error(message)
})

app.on('ready', () => {	
	createWindow();	
});

app.on('window-all-closed', () => {	
	if (process.platform !== 'darwin') {
		app.quit();
	}
});

app.on('activate', () => {
	if (win === null) {
		createWindow();
	}
});